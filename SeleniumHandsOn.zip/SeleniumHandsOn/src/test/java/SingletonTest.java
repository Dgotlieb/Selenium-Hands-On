import org.testng.annotations.Test;

public class SingletonTest {
    @Test
    public void test01(){
        new SamplePage().pressElement();
    }
}
