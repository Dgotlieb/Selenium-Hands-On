public class Constants {
    public static final String CHROMEDRIVER_PATH = "/Users/danielgotlieb/Downloads/chromedriver";
}
