public class SleepTest {
    public static void main(String[] args) throws InterruptedException {
        System.out.println(1);
        Thread.sleep(5000);
        System.out.println(6);
    }
}
